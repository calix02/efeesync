import React from "react";
const Letter = React.forwardRef(({animate, onAnimationEnd,onClose}, ref) =>{


    return( 
        <div ref={ref}   className={` ${animate} lg:w-[420px] w-[390px] h-125 px-8 bg-white shadow-[2px_2px_#8A2791,-2px_-2px_white] rounded-[10px] absolute z-50 inset-0 mx-auto mt-16 `}
        onAnimationEnd={onAnimationEnd}>
            <div className="mt-[10px] relative">
                <span onClick={onClose} className="material-symbols-outlined absolute right-0.5 cursor-pointer">disabled_by_default</span>
            </div>
            <div className=" text-sm text-[#000] mt-8  flex flex-col">
                <span className="text-2xl font-bold text-[#621668]">Tech Night 2025</span>
                <span className="mt-3">Student Name: Jerick Gamboa</span>
                <span>Year & Section: 3A</span>
                <span>Absence Date: May 22, 2025</span>
                <span>Submitted Date: May 22, 2025</span>
                <span className="mt-3">Attachment</span>
                <div className="w-[100%] overflow-y-scroll p-4 h-70 bg-[#D9D9D9] rounded-md">
                    <p>Dear Charo,</p>
                </div>
            </div>
            
        </div>
       
    );
});
export default Letter;